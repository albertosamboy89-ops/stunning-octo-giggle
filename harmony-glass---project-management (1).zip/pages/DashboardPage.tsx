
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Client } from '../types';
import BottomNav from '../components/BottomNav';
import AppHeader from '../components/AppHeader';

interface DashboardPageProps {
  readonly?: boolean;
  clients: Client[];
  onSelectClient: (id: number) => void;
  onDeleteClient?: (id: number) => void;
}

const DashboardPage: React.FC<DashboardPageProps> = ({ readonly = false, clients, onSelectClient, onDeleteClient }) => {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');
  const [clientToDelete, setClientToDelete] = useState<Client | null>(null);

  const handleCardClick = (client: Client) => {
    onSelectClient(client.id);
    navigate('/expense-management');
  };

  const filteredClients = clients.filter(client => 
    client.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    client.desc.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const getBudgetInfo = (client: Client) => {
    const abono = client.abonoTotal || 0;
    const spent = client.expenses?.reduce((sum, e) => sum + e.amount, 0) || 0;
    
    // Caja: Basado en el abono inicial
    const remainingInCaja = abono - spent;
    const cajaPct = abono > 0 ? Math.max(0, (remainingInCaja / abono) * 100) : 0;
    
    // Rentabilidad: Basado en el total del contrato
    const utility = client.total - spent;
    const isOverBudget = spent > client.total;
    
    let colorClass = "bg-green-500 shadow-glow-green";
    if (cajaPct <= 0) colorClass = "bg-slate-900 dark:bg-white";
    else if (cajaPct <= 30) colorClass = "bg-red-500 shadow-glow-red";
    else if (cajaPct <= 60) colorClass = "bg-orange-500 shadow-glow-orange";
    
    return { cajaPct, colorClass, remainingInCaja, utility, isOverBudget };
  };

  return (
    <div className="pb-40 min-h-screen bg-slate-50 dark:bg-[#020617] relative overflow-hidden">
      <div className="absolute top-[-100px] right-[-100px] size-[400px] bg-primary/10 rounded-full blur-[100px] pointer-events-none"></div>

      <AppHeader />

      <main className="px-6 mt-8 animate-fade-up max-w-2xl mx-auto">
        <div className="relative mb-10">
          <span className="material-symbols-outlined absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 font-bold">search</span>
          <input 
            className="w-full h-14 bg-white/70 dark:bg-slate-800/50 border border-slate-200 dark:border-white/5 rounded-3xl pl-12 pr-4 text-sm focus:ring-2 focus:ring-primary/30 outline-none shadow-sm transition-all"
            placeholder="Buscar proyectos en curso..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>

        <div className="flex items-center justify-between mb-8 px-2">
          <h2 className="text-xl font-black text-slate-800 dark:text-slate-100 uppercase tracking-tight">Proyectos Activos</h2>
          <span className="text-[10px] font-black text-primary bg-primary/10 px-4 py-1.5 rounded-full uppercase tracking-widest">{filteredClients.length} Proyectos</span>
        </div>

        <div className="grid gap-6">
          {filteredClients.map((item) => {
            const { cajaPct, colorClass, remainingInCaja, utility, isOverBudget } = getBudgetInfo(item);
            return (
              <div 
                key={item.id} 
                className={`glass-card rounded-[2.5rem] p-7 group transition-all animate-fade-up relative overflow-hidden border-l-8 ${isOverBudget ? 'border-l-harmony-red bg-red-50/50 dark:bg-red-900/10' : 'border-l-primary'}`}
              >
                <div onClick={() => handleCardClick(item)} className="cursor-pointer">
                  <div className="flex justify-between items-start mb-6">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <h3 className={`font-black text-xl leading-tight ${isOverBudget ? 'text-harmony-red' : 'text-slate-900 dark:text-white group-hover:text-primary'}`}>{item.name}</h3>
                        {isOverBudget && <span className="material-symbols-outlined text-harmony-red animate-pulse">warning</span>}
                      </div>
                      <p className="text-[10px] font-bold text-slate-400 uppercase tracking-[0.2em]">{item.desc}</p>
                    </div>
                    <div className="flex flex-col items-end gap-3">
                      <span className={`text-[9px] font-black px-4 py-1.5 rounded-full border ${isOverBudget ? 'bg-harmony-red text-white border-harmony-red' : (cajaPct <= 0 ? 'bg-black text-white border-black' : 'bg-primary/5 text-primary border-primary/20')} uppercase tracking-widest shadow-sm`}>
                        {isOverBudget ? 'SOBRECOSTO' : (cajaPct <= 0 ? 'AGOTADO' : item.status)}
                      </span>
                      {!readonly && onDeleteClient && (
                        <button 
                          onClick={(e) => { e.stopPropagation(); setClientToDelete(item); }}
                          className="size-10 bg-red-500/5 text-red-500 rounded-xl flex items-center justify-center hover:bg-red-500 hover:text-white transition-all"
                        >
                          <span className="material-symbols-outlined text-xl">archive</span>
                        </button>
                      )}
                    </div>
                  </div>

                  <div className="bg-slate-50/50 dark:bg-white/5 rounded-3xl p-5 mb-6 grid grid-cols-2 gap-4 border border-slate-100 dark:border-white/5">
                    <div>
                      <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest block mb-1">Monto Obra</span>
                      <span className="text-base font-black text-slate-900 dark:text-slate-100">$ {item.total.toLocaleString()}</span>
                    </div>
                    <div className="text-right">
                      <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest block mb-1">Utilidad Estimada</span>
                      <span className={`text-base font-black ${utility < 0 ? 'text-harmony-red' : 'text-green-500'}`}>$ {utility.toLocaleString()}</span>
                    </div>
                  </div>

                  <div className="space-y-3">
                    <div className="flex justify-between items-end">
                      <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Saldo en Caja (Abono)</span>
                      <span className={`text-sm font-black ${cajaPct <= 30 ? 'text-harmony-red' : 'text-slate-900 dark:text-white'}`}>
                        $ {remainingInCaja.toLocaleString()}
                      </span>
                    </div>
                    <div className="relative h-3 w-full bg-slate-200 dark:bg-slate-800 rounded-full overflow-hidden">
                      <div className={`absolute top-0 left-0 h-full rounded-full transition-all duration-1000 ${colorClass}`} style={{ width: `${cajaPct}%` }}></div>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}

          {filteredClients.length === 0 && (
            <div className="text-center py-24 animate-fade-up">
              <div className="size-24 bg-slate-100 dark:bg-slate-900 mx-auto rounded-full flex items-center justify-center mb-6">
                <span className="material-symbols-outlined text-5xl text-slate-300">inventory_2</span>
              </div>
              <h3 className="text-sm font-black text-slate-400 uppercase tracking-[0.3em]">Sin proyectos activos</h3>
              <p className="text-[10px] text-slate-400 mt-2 uppercase tracking-widest">Inicia un nuevo registro para comenzar</p>
            </div>
          )}
        </div>
      </main>

      {!readonly && (
        <div className="fixed bottom-32 left-0 right-0 px-6 flex justify-center z-40 pointer-events-none">
          <button 
            onClick={() => navigate('/new-client')}
            className="pointer-events-auto h-16 px-10 bg-primary text-white rounded-3xl font-black uppercase tracking-widest text-xs shadow-2xl shadow-primary/40 hover:scale-105 active:scale-95 transition-all flex items-center gap-3"
          >
            <span className="material-symbols-outlined">add_circle</span>
            Nuevo Proyecto
          </button>
        </div>
      )}

      {clientToDelete && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-6 bg-slate-950/90 backdrop-blur-md animate-fade-in">
          <div className="glass-card w-full max-w-sm rounded-[3rem] p-10 space-y-8 animate-fade-up border-t-8 border-t-primary">
            <div className="flex flex-col items-center text-center space-y-4">
              <div className="size-20 bg-primary/10 rounded-full flex items-center justify-center text-primary border border-primary/20">
                <span className="material-symbols-outlined text-4xl">folder_zip</span>
              </div>
              <div className="space-y-2">
                <h4 className="text-xl font-black text-slate-900 dark:text-white uppercase tracking-tighter">Finalizar Proyecto</h4>
                <p className="text-xs text-slate-500 font-bold leading-relaxed px-4">¿Confirmas que la obra de <span className="text-primary font-black uppercase tracking-widest">{clientToDelete.name}</span> ha concluido satisfactoriamente?</p>
              </div>
            </div>

            <div className="flex gap-4">
              <button onClick={() => setClientToDelete(null)} className="flex-1 h-14 rounded-2xl font-black text-[10px] uppercase text-slate-400">Cancelar</button>
              <button 
                onClick={() => { onDeleteClient?.(clientToDelete.id); setClientToDelete(null); }}
                className="flex-[2] h-14 bg-primary text-white rounded-2xl font-black text-[10px] uppercase tracking-widest shadow-xl shadow-primary/20 transition-all active:scale-95"
              >
                Sí, Archivar
              </button>
            </div>
          </div>
        </div>
      )}

      <BottomNav />
    </div>
  );
};

export default DashboardPage;
